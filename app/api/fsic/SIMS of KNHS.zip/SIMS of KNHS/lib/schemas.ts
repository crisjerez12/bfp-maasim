import { z } from 'zod'

export const UserSchema = z.object({
  username: z.string().min(3).max(20),
  password: z.string().min(6),
  email: z.string().email(),
  role: z.enum(['student', 'teacher', 'admin']).default('student'),
  firstName: z.string(),
  lastName: z.string(),
  createdAt: z.date().default(() => new Date()),
  updatedAt: z.date().default(() => new Date()),
})

export type User = z.infer<typeof UserSchema>

