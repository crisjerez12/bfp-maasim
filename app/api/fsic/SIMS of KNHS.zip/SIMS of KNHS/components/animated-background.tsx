'use client'

import { useTheme } from 'next-themes'
import { motion } from 'framer-motion'

export default function AnimatedBackground() {
  const { theme } = useTheme()

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden bg-gradient-to-br from-blue-50 to-white dark:from-blue-950 dark:to-gray-950">
      <motion.div
        className="absolute inset-0 z-[-1]"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        {[...Array(50)].map((_, i) => (
          <motion.div
            key={i}
            className={`absolute h-[20vmin] w-[20vmin] rounded-full ${
              theme === 'dark' 
                ? 'bg-blue-600/5 backdrop-blur-3xl' 
                : 'bg-blue-600/5 backdrop-blur-3xl'
            }`}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            initial={{ scale: 0, x: '-50%', y: '-50%' }}
            animate={{
              scale: [0, 1, 0.8],
              x: ['-50%', '-50%'],
              y: ['-50%', '-50%'],
            }}
            transition={{
              duration: Math.random() * 5 + 5,
              repeat: Infinity,
              repeatType: 'reverse',
            }}
          />
        ))}
      </motion.div>
    </div>
  )
}

