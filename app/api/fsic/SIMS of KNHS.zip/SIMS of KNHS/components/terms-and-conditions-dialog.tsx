import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

interface TermsAndConditionsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onAgree: () => void
}

export default function TermsAndConditionsDialog({
  open,
  onOpenChange,
  onAgree,
}: TermsAndConditionsDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Terms and Conditions</DialogTitle>
          <DialogDescription>
            Please read and agree to the following terms and conditions.
          </DialogDescription>
        </DialogHeader>
        <div className="max-h-[300px] overflow-auto">
          <p className="text-sm text-muted-foreground">
            1. Acceptance of Terms: By accessing and using the School Information Management System (SIMS) of Kiamba National High School, you agree to be bound by these Terms and Conditions.

            2. User Accounts: You are responsible for maintaining the confidentiality of your account and password. Notify the school administration immediately if you suspect any unauthorized use of your account.

            3. Proper Use: The SIMS is to be used for educational and administrative purposes only. Any misuse or unauthorized access may result in disciplinary action.

            4. Data Privacy: We are committed to protecting your personal information. By using SIMS, you consent to the collection and use of your data as outlined in our Privacy Policy.

            5. Intellectual Property: All content and materials available on SIMS are the property of Kiamba National High School and are protected by copyright laws.

            6. Modifications to Service: We reserve the right to modify or discontinue, temporarily or permanently, the service with or without notice.

            7. Limitation of Liability: Kiamba National High School shall not be liable for any indirect, incidental, special, consequential or punitive damages resulting from your use of SIMS.

            8. Governing Law: These Terms and Conditions shall be governed by and construed in accordance with the laws of the Philippines.

            9. Changes to Terms: We reserve the right to update these Terms and Conditions at any time. Continued use of SIMS after any such changes shall constitute your consent to such changes.

            10. Contact Information: For any questions about these Terms and Conditions, please contact the school administration.
          </p>
        </div>
        <DialogFooter>
          <Button onClick={onAgree}>I Agree</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

