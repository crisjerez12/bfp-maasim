'use client'

import { Card } from '@/components/ui/card'
import { Calendar } from '@/components/ui/calendar'
import { Users, FileText, Package, CalendarIcon } from 'lucide-react'
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from 'recharts'
import { useState } from 'react'

const monthlyData = [
  { name: 'Jan', value: 20 },
  { name: 'Feb', value: 15 },
  { name: 'Mar', value: 40 },
  { name: 'Apr', value: 75 },
  { name: 'May', value: 190 },
  { name: 'Jun', value: 240 },
  { name: 'Jul', value: 110 },
  { name: 'Aug', value: 240 },
  { name: 'Sep', value: 100 },
  { name: 'Oct', value: 175 },
  { name: 'Nov', value: 140 },
  { name: 'Dec', value: 100 },
]

export default function DashboardContent() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="p-6">
          <div className="flex items-center space-x-2">
            <Users className="h-4 w-4 text-blue-500" />
            <h3 className="text-sm font-medium">Students Relayed</h3>
          </div>
          <div className="flex items-center space-x-2">
            <div className="text-2xl font-bold text-blue-500">1000</div>
            <p className="text-xs text-muted-foreground">
              Total number of students with grades
            </p>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center space-x-2">
            <FileText className="h-4 w-4 text-green-500" />
            <h3 className="text-sm font-medium">Responses Received</h3>
          </div>
          <div className="flex items-center space-x-2">
            <div className="text-2xl font-bold text-green-500">500</div>
            <p className="text-xs text-muted-foreground">
              Number of responses from the survey website
            </p>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center space-x-2">
            <Package className="h-4 w-4 text-orange-500" />
            <h3 className="text-sm font-medium">Inventory Inputted</h3>
          </div>
          <div className="flex items-center space-x-2">
            <div className="text-2xl font-bold text-orange-500">300</div>
            <p className="text-xs text-muted-foreground">
              Total items in the inventory system
            </p>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center space-x-2">
            <CalendarIcon className="h-4 w-4 text-purple-500" />
            <h3 className="text-sm font-medium">Upcoming Projects</h3>
          </div>
          <div className="flex items-center space-x-2">
            <div className="text-2xl font-bold text-purple-500">0</div>
            <p className="text-xs text-muted-foreground">
              Number of scheduled projects this month
            </p>
          </div>
        </Card>
      </div>
      <div className="grid gap-4 md:grid-cols-7 lg:grid-cols-5">
        <Card className="col-span-4">
          <div className="p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Monthly Responses</h3>
              <div className="text-sm text-muted-foreground">This Year: 1442</div>
            </div>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData}>
                  <XAxis
                    dataKey="name"
                    stroke="#888888"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    stroke="#888888"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `${value}`}
                  />
                  <Bar
                    dataKey="value"
                    fill="currentColor"
                    radius={[4, 4, 0, 0]}
                    className="fill-primary"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Card>
        <div className="col-span-3 lg:col-span-1 space-y-4">
          <Card>
            <div className="p-6">
              <h3 className="text-lg font-medium mb-4">Upcoming Projects</h3>
              <div className="space-y-2">
                <div className="text-sm">No projects scheduled</div>
              </div>
            </div>
          </Card>
          <Card>
            <div className="p-6">
              <h3 className="text-lg font-medium mb-4">Calendar</h3>
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                className="rounded-md border"
              />
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}

