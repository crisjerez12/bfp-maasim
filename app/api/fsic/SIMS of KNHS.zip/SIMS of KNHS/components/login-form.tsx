// ... (previous imports remain the same)
import { useRouter } from 'next/navigation'

export default function LoginForm() {
  // ... (previous state declarations remain the same)
  const router = useRouter()

  const handleSubmit = async (formData: FormData) => {
    setError(null)
    const result = await login(formData)
    if (result.success) {
      toast({
        title: "Login Successful",
        description: `Welcome back, ${result.user?.username}!`,
        duration: 3000,
      })
      router.push('/dashboard')
    } else {
      setError(result.message)
    }
  }

  // ... (rest of the component remains the same)
}

