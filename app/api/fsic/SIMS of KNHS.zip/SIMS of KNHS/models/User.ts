import { ObjectId } from 'mongodb'
import clientPromise from '../lib/mongodb'
import { User, UserSchema } from '../lib/schemas'

export class UserModel {
  private static async getCollection() {
    const client = await clientPromise
    const db = client.db('sims_knhs')
    return db.collection<User>('users')
  }

  static async create(userData: Omit<User, 'createdAt' | 'updatedAt'>): Promise<User> {
    const collection = await this.getCollection()
    const validatedUser = UserSchema.parse({
      ...userData,
      createdAt: new Date(),
      updatedAt: new Date(),
    })
    const result = await collection.insertOne(validatedUser)
    return { ...validatedUser, _id: result.insertedId }
  }

  static async findByUsername(username: string): Promise<User | null> {
    const collection = await this.getCollection()
    const user = await collection.findOne({ username })
    return user ? UserSchema.parse(user) : null
  }

  static async findById(id: string): Promise<User | null> {
    const collection = await this.getCollection()
    const user = await collection.findOne({ _id: new ObjectId(id) })
    return user ? UserSchema.parse(user) : null
  }

  static async updateUser(id: string, updateData: Partial<User>): Promise<User | null> {
    const collection = await this.getCollection()
    const updatedUser = await collection.findOneAndUpdate(
      { _id: new ObjectId(id) },
      { $set: { ...updateData, updatedAt: new Date() } },
      { returnDocument: 'after' }
    )
    return updatedUser ? UserSchema.parse(updatedUser) : null
  }

  static async deleteUser(id: string): Promise<boolean> {
    const collection = await this.getCollection()
    const result = await collection.deleteOne({ _id: new ObjectId(id) })
    return result.deletedCount === 1
  }

  static async listUsers(page: number = 1, limit: number = 10): Promise<User[]> {
    const collection = await this.getCollection()
    const users = await collection.find()
      .skip((page - 1) * limit)
      .limit(limit)
      .toArray()
    return users.map(user => UserSchema.parse(user))
  }
}

