import LoginForm from '@/components/login-form'
import AnimatedBackground from '@/components/animated-background'

export default function LoginPage() {
  return (
    <div className="relative min-h-screen flex items-center justify-center bg-background">
      <AnimatedBackground />
      <LoginForm />
    </div>
  )
}

