'use server'

import { cookies } from 'next/headers'
import { UserModel } from '@/models/User'
import bcrypt from 'bcryptjs'
import { UserSchema } from '@/lib/schemas'
import { z } from 'zod'

type AuthResult = {
  success: boolean;
  message: string;
  user?: {
    id: string;
    username: string;
    role: string;
  };
}

const LoginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters long"),
  password: z.string().min(6, "Password must be at least 6 characters long"),
})

const RegisterSchema = UserSchema.omit({ createdAt: true, updatedAt: true })

export async function login(formData: FormData): Promise<AuthResult> {
  try {
    const { username, password } = LoginSchema.parse(Object.fromEntries(formData))

    const user = await UserModel.findByUsername(username)

    if (!user) {
      return { success: false, message: 'Invalid username or password' }
    }

    const isPasswordValid = await bcrypt.compare(password, user.password)

    if (!isPasswordValid) {
      return { success: false, message: 'Invalid username or password' }
    }

    // Set a session cookie
    cookies().set('session', user._id.toString(), { 
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 60 * 60 * 24 * 7, // 1 week
      path: '/',
    })

    return { 
      success: true, 
      message: 'Login successful',
      user: {
        id: user._id.toString(),
        username: user.username,
        role: user.role,
      }
    }
  } catch (error) {
    console.error('Login error:', error)
    if (error instanceof z.ZodError) {
      return { success: false, message: error.errors[0].message }
    }
    return { success: false, message: 'An error occurred during login' }
  }
}

export async function register(formData: FormData): Promise<AuthResult> {
  try {
    const userData = RegisterSchema.parse(Object.fromEntries(formData))
    
    const existingUser = await UserModel.findByUsername(userData.username)
    if (existingUser) {
      return { success: false, message: 'Username already exists' }
    }

    const hashedPassword = await bcrypt.hash(userData.password, 12)
    
    const newUser = await UserModel.create({
      ...userData,
      password: hashedPassword,
    })

    return { 
      success: true, 
      message: 'User registered successfully',
      user: {
        id: newUser._id.toString(),
        username: newUser.username,
        role: newUser.role,
      }
    }
  } catch (error) {
    console.error('Registration error:', error)
    if (error instanceof z.ZodError) {
      return { success: false, message: error.errors[0].message }
    }
    return { success: false, message: 'An error occurred during registration' }
  }
}

export async function logout(): Promise<AuthResult> {
  try {
    cookies().delete('session')
    return { success: true, message: 'Logged out successfully' }
  } catch (error) {
    console.error('Logout error:', error)
    return { success: false, message: 'An error occurred during logout' }
  }
}

export async function getCurrentUser(): Promise<AuthResult> {
  try {
    const sessionId = cookies().get('session')?.value
    if (!sessionId) {
      return { success: false, message: 'No active session' }
    }

    const user = await UserModel.findById(sessionId)
    if (!user) {
      cookies().delete('session')
      return { success: false, message: 'Invalid session' }
    }

    return { 
      success: true, 
      message: 'User session retrieved',
      user: {
        id: user._id.toString(),
        username: user.username,
        role: user.role,
      }
    }
  } catch (error) {
    console.error('Get current user error:', error)
    return { success: false, message: 'An error occurred while retrieving user session' }
  }
}

