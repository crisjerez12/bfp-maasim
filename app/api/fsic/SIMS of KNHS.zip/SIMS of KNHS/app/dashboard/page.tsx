import { Metadata } from 'next'
import DashboardContent from '@/components/dashboard/dashboard-content'

export const metadata: Metadata = {
  title: 'Dashboard - KNHS SIMS',
  description: 'School Information Management System Dashboard',
}

export default function DashboardPage() {
  return <DashboardContent />
}

